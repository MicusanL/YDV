const stripeOverlay = document.querySelector('[data-stripe-overlay]')

if (stripeOverlay) {
	const overlayClose = stripeOverlay.querySelector('[data-stripe-close]')
	const overlaySubmit = stripeOverlay.querySelector('[data-stripe-submit]')
	const overlaySelect = stripeOverlay.querySelector('[data-stripe-select]')

	if (!sessionStorage.getItem('stripe-inactive') || sessionStorage.getItem('stripe-inactive') !== 'true') {
		setTimeout(() => {
			stripeOverlay.classList.add('is-active')
		}, 3000)
	}

	overlayClose.addEventListener('click', () => {
		stripeOverlay.classList.remove('is-active')

		// Add a item of stripe inactive in the session storage
		sessionStorage.setItem('stripe-inactive', true)
	})

	overlaySubmit.addEventListener('click', () => {
		const selectedValue = overlaySelect.value

		switch (selectedValue) {
			case '1':
				window.open('https://buy.stripe.com/3cs28H0m5bDRg485kq', '_blank') // 10 lei one-time
				break
			case '2':
				window.open('https://buy.stripe.com/cN2fZx1q923h2di14b', '_blank') // 10 lei subscription
				break
			case '3':
				window.open('https://buy.stripe.com/eVa14D1q98rFg48bIM', '_blank') // 25 lei one-time
				break
			case '4':
				window.open('https://buy.stripe.com/aEUeVt5Gp4bp2difZ6', '_blank') // 25 lei subscription
				break
			case '5':
				window.open('https://buy.stripe.com/4gw28H4Cl5ft7xC6ot', '_blank') // 50 lei one-time
				break
			case '6':
				window.open('https://buy.stripe.com/bIY3cLb0J5ftcRWaEN', '_blank') // 50 lei subscription
				break
			default:
				console.log('Nu este suma selectata')
		}
	})
}
